import view.AppView;

public class Main {
    public static void main(String[] args) {
        AppView app = new AppView();
        app.run();
    }
}
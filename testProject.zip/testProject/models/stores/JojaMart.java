package models.stores;

public class JojaMart extends Market {


    public JojaMart() {
        shopAssistantName = "Morris";
        startHour = 9;
        endHour = 23;
        //goods
    }


}

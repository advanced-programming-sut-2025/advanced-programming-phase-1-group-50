package models.stores;

public class CarpenterShop extends Market {

    public CarpenterShop() {
        shopAssistantName = "Robin";
        startHour = 9;
        endHour = 20;
        //goods
    }


}

package models.stores;

public class Blacksmith extends Market {

    public Blacksmith() {
        shopAssistantName = "Clint";
        startHour = 9;
        endHour = 16;
        //goods
    }



}

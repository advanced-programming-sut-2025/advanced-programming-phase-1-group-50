package models.mapInfo;

public class Wood {
}

package models.mapInfo;

import models.Placeable;

import java.awt.*;

public class GreenHouse implements Placeable {
    private boolean isBroken;
    private final  Rectangle bounds;
    private final char symbol = 'G';
    public GreenHouse(int x, int y, int width, int height) {
        bounds = new Rectangle(x, y, width, height);
        this.isBroken = true;
    }
    public Rectangle getBounds() {
        return bounds;
    }
    public boolean isBroken() {
        return isBroken;
    }
    public void setBroken(boolean broken) {
        isBroken = broken;
    }
    public char getSymbol(){
        return symbol;
    }
}

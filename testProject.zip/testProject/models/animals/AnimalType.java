package models.animals;

public enum AnimalType {
    Barn,
    Coop;

}

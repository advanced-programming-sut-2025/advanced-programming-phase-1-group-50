package models;

import models.mapInfo.Position;

import java.awt.*;

public interface Placeable {
    Rectangle getBounds();
    char getSymbol();
}

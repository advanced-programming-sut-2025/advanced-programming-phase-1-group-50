package models.NPCs;

public class Quest {
}

package models.NPCs;

public enum FriendshipLevel {
        firstLevel,
        secondLevel,
        thirdLevel;
}

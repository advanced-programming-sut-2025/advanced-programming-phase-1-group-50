package models.userInfo;

public class Coin {
    private int value;

}

package models.foraging;

public class Crop {
    private ForagingQuality quality;
    private CropType type;


    public int calculatePrice() {
        return 0;
    }
}

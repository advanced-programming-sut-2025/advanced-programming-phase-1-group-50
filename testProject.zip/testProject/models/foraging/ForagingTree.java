package models.foraging;

public class ForagingTree {
    private ForagingTreesTypes foragingTreesType;
}

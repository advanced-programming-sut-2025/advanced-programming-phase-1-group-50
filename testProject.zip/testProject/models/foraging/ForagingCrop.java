package models.foraging;

public class ForagingCrop {
    private ForagingCropsType type;
}

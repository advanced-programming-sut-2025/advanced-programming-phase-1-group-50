package models.waterBodies;

public class Sea extends WaterBody {
}

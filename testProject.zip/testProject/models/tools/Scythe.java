package models.tools;

public class Scythe extends Tool {
    @Override
    protected int getConsumptionEnergy() {
        return 0;
    }

    @Override
    protected void useTool() {

    }


}

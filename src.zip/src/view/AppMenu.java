package view;

import java.util.Scanner;

public interface AppMenu {
    abstract void check(Scanner scanner);
}

package view;

import java.util.Scanner;

public class ExitMenu implements AppMenu{
    public void check(Scanner scanner) {

    }
}

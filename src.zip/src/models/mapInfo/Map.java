package models.mapInfo;

import java.util.ArrayList;

public enum Map {
    Map1(),
    Map2(),
    Map3(),
    Map4();


    private ArrayList<Tile> tiles;

    public void thunder(){

    }
}
package models.mapInfo;

public enum TileType {
}

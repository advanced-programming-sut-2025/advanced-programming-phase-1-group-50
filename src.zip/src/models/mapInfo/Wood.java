package models.mapInfo;

import models.manuFactor.Ingredient;

public class Wood implements Ingredient {
}

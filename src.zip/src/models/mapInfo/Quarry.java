package models.mapInfo;

public class Quarry {
}

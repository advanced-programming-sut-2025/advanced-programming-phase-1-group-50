package models.stores;

public class JojaMart extends Market {


    public JojaMart() {
        shopAssistantName = "Morris";
        startHour = 9;
        endHour = 23;
        //goods
    }


    @Override
    public void removeGood() {

    }

    @Override
    public void addGood() {

    }

    @Override
    public void sellProduct() {

    }

    @Override
    public String showAllProducts() {
        return "";
    }

    @Override
    public String showAllAvailableProducts() {
        return "";
    }

    @Override
    public void purchase() {

    }
}

package models.stores;

public class CarpenterShop extends Market {

    public CarpenterShop() {
        shopAssistantName = "Robin";
        startHour = 9;
        endHour = 20;
        //goods
    }


    @Override
    public void removeGood() {

    }

    @Override
    public void addGood() {

    }

    @Override
    public void sellProduct() {

    }

    @Override
    public String showAllProducts() {
        return "";
    }

    @Override
    public String showAllAvailableProducts() {
        return "";
    }

    @Override
    public void purchase() {

    }
}

package models.stores;

public class FishShop extends Market {

    public FishShop() {
        shopAssistantName = "Willy";
        startHour = 9;
        endHour = 17;
        //goods
    }


    @Override
    public void removeGood() {

    }

    @Override
    public void addGood() {

    }

    @Override
    public void sellProduct() {

    }

    @Override
    public String showAllProducts() {
        return "";
    }

    @Override
    public String showAllAvailableProducts() {
        return "";
    }

    @Override
    public void purchase() {

    }
}

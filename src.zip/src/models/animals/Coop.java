package models.animals;

public class Coop {
}

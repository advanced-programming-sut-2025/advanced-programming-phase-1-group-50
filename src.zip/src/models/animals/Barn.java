package models.animals;

public class Barn {
}

package models.NPCs;

public class Gift {

}

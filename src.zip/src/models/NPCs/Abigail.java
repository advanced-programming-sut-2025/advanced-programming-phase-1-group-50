package models.NPCs;

public class Abigail extends NPC{
    @Override
    public String getCurrentDialogue() {
        return "";
    }

    @Override
    public void increaseFriendShipLevel() {

    }

    @Override
    public boolean isFavoriteGift() {
        return false;
    }

    @Override
    public void givingGiftToPlayer() {

    }

    @Override
    public void talkToPlayer() {

    }

    @Override
    public void doQuest() {

    }
}

package models.date;

public enum Season {
    Spring(),
    Summer(),
    Fall(),
    Winter(),
    Special();

    private String season;
}

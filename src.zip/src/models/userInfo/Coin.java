package models.userInfo;

public class Coin {
}

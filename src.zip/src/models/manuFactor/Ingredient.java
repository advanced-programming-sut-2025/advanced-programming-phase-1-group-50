package models.manuFactor;

public interface Ingredient {
}

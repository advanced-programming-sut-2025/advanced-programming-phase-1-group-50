package models.manuFactor.artisanGoods;

public enum BarType {
    Iron,
    Gold,
    Iridium,
    Copper;
}

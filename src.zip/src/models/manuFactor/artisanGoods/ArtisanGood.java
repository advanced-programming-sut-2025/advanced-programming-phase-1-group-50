package models.manuFactor.artisanGoods;

public interface ArtisanGood {
}

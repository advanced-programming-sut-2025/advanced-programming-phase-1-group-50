package models.tools;

public class MilkPail extends Tool {
    @Override
    protected int getConsumptionEnergy() {
        return 0;
    }

    @Override
    protected void useTool() {

    }
}

package models.tools;

public class FishingPole extends Tool {
    private ToolType type = ToolType.Primary;

    private void upgradeTool() {

    }

    @Override
    protected int getConsumptionEnergy() {
        return 0;
    }

    @Override
    protected void useTool() {

    }


}

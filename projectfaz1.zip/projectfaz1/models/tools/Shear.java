package models.tools;

public class Shear extends Tool {
    @Override
    protected int getConsumptionEnergy() {
        return 0;
    }

    @Override
    protected void useTool() {

    }

}

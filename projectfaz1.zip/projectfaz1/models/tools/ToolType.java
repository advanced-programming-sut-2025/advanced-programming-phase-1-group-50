package models.tools;

public enum ToolType {
    Primary,
    Coppery,
    Metal,
    Golden,
    Iridium,
    FiberGlass,
    Bamboo;
}

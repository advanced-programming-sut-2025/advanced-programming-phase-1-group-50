package models.foraging;

public class ForagingSeed {
    private ForagingSeedsTypes type;
}

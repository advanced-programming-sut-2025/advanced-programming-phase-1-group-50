package models.foraging;

public class Tree {
    private TreeType type;

}

package models.foraging;

public class ForagingMineral {
    private ForagingMineralsTypes type;
}

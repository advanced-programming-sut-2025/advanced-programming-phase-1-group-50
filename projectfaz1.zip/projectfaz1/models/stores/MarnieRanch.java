package models.stores;

public class MarnieRanch extends Market {

    public MarnieRanch() {
        shopAssistantName = "Marnie";
        startHour = 9;
        endHour = 16;
        //goods
    }
}

package models.stores;

public class StardropSaloon extends Market {


    public StardropSaloon() {
        shopAssistantName = "Gus";
        startHour = 12;
        endHour = 24;
        //goods
    }
}

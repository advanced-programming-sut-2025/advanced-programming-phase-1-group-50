package models.stores;

public class PierreGeneralStore extends Market {


    public PierreGeneralStore() {
        shopAssistantName = "Pierre";
        startHour = 9;
        endHour = 23;
        //goods
    }

}

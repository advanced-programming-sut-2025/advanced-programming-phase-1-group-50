package models.stores;

public class FishShop extends Market {

    public FishShop() {
        shopAssistantName = "Willy";
        startHour = 9;
        endHour = 17;
        //goods
    }


}

package models.manuFactor;

public enum ManuFactoringMachine {
    BeeHouse(),
    CheesePress(),
    Keg(),
    Dehydrator(),
    CharcoalKiln(),
    Loom(),
    MayonnaiseMachine(),
    OilMaker(),
    PreservesJar(),
    FishSmoker(),
    Furnace();
}

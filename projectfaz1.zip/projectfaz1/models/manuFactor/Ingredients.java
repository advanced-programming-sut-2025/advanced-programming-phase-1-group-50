package models.manuFactor;

public class Ingredients {
}

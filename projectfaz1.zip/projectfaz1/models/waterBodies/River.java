package models.waterBodies;

public class River extends WaterBody {
}

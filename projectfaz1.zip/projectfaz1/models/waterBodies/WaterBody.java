package models.waterBodies;

public abstract class WaterBody {

}

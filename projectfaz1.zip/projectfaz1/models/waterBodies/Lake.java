package models.waterBodies;

public class Lake extends WaterBody {
}

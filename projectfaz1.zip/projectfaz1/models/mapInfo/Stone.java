package models.mapInfo;

public class Stone {
}

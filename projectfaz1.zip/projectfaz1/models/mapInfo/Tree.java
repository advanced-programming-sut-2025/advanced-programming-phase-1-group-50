package models.mapInfo;

public class Tree {
}

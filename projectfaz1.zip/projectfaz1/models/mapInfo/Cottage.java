package models.mapInfo;

public class Cottage {
    private final int width;
    private final int length;

    public Cottage(int width, int length) {
        this.width = width;
        this.length = length;
    }
}

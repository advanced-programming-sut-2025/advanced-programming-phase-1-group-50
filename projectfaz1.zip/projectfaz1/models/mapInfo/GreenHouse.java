package models.mapInfo;

public class GreenHouse {
    private boolean isBrocken;
    private final int rows = 5;
    private final int cols = 6;
}

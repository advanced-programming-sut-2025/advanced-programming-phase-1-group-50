package models.recipes;

public enum CookingRecipe {
    Friedegg(),
    BakedFish(),
    Salad(),
    Olmelet(),
    PumpkinPie(),
    Spaghetti(),
    Pizza(),
    Tortilla(),
    MakiRoll(),
    TripleShotEspresso(),
    Cookie(),
    HashBrowns(),
    Pancakes(),
    FruitSalad(),
    RedPlate(),
    Bread(),
    SalmonDinner(),
    VegetableMedley(),
    FarmersLunch(),
    SurvivalBurger(),
    DishOTheSea(),
    SeaformPudding(),
    MinersTreat();

}
